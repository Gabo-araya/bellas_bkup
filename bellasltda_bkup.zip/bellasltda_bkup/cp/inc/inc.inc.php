<?php
require('connect.inc.php');
include('fx/conf.fx.php');
include('fx/general.fx.php');
include('fx/layout.fx.php');
//include('fx/validations.fx');
?>