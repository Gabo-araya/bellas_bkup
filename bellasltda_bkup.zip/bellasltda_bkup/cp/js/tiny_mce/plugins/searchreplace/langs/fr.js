// FR lang variables
// Modified by keyko-web.net, last updated 2007-03-08, based on the work of Motte

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Rechercher',
searchreplace_searchnext_desc : 'Rechercher suivant',
searchreplace_replace_desc : 'Rechercher/Remplacer',
searchreplace_notfound : 'Recherche compl&eacute;t&eacute;e. La fin du document a &eacute;t&eacute; atteinte.',
searchreplace_search_title : 'Rechercher',
searchreplace_replace_title : 'Rechercher/Remplacer',
searchreplace_allreplaced : 'Action termin&eacute;e avec succ&egrave;s. Les remplacements\nont &eacute;t&eacute; faits dans l\'ensemble du document.',
searchreplace_findwhat : 'Trouver le mot',
searchreplace_replacewith : 'Remplacer par',
searchreplace_direction : 'Direction',
searchreplace_up : 'Vers le haut',
searchreplace_down : 'Vers le bas',
searchreplace_case : 'Respecter la casse',
searchreplace_findnext : 'Suivant',
searchreplace_replace : 'Remplacer',
searchreplace_replaceall : 'Remplacer tout',
searchreplace_cancel : 'Annuler'
});
