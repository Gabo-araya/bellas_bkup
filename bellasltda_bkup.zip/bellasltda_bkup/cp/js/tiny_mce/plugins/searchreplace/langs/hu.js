// HU lang variables

tinyMCE.addToLang('',{
searchreplace_search_desc : 'Keresés',
searchreplace_searchnext_desc : 'Újra keresés',
searchreplace_replace_desc : 'Keres/Cserél',
searchreplace_notfound : 'A keresés elkészült. A keresési szöveg nem található.',
searchreplace_search_title : 'Keres',
searchreplace_replace_title : 'Keres/Cserél',
searchreplace_allreplaced : 'A kereséséi szöveg minden elõfordulása cserélve lett.',
searchreplace_findwhat : 'Mit keres',
searchreplace_replacewith : 'Mire cserél',
searchreplace_direction : 'Hatókör',
searchreplace_up : 'Fel',
searchreplace_down : 'Le',
searchreplace_case : 'Teljes szó',
searchreplace_findnext : 'Következõt&nbsp;keres',
searchreplace_replace : 'Cserél',
searchreplace_replaceall : 'Mindent&nbsp;cserél',
searchreplace_cancel : 'Mégse'
});
