ï»¿// DK lang variables - Transl.:Jan Moelgaard, Bo Frederiksen, John Dalsgaard - Corr.:

tinyMCE.addToLang('',{
searchreplace_search_desc : 'S&oslash;g',
searchreplace_searchnext_desc : 'S&oslash;g igen',
searchreplace_replace_desc : 'S&oslash;g og erstat',
searchreplace_notfound : 'SÃ¸gningen er f&aelig;rdig.\nS&oslash;geudtrykket kunne ikke findes.',
searchreplace_search_title : 'S&oslash;g',
searchreplace_replace_title : 'S&oslash;g og erstat',
searchreplace_allreplaced : 'Alle forekomster af s&oslash;geudtrykket blev erstattet.',
searchreplace_findwhat : 'S&oslash;g efter',
searchreplace_replacewith : 'Erstat det med',
searchreplace_direction : 'Retning',
searchreplace_up : 'Op',
searchreplace_down : 'Ned',
searchreplace_case : 'Skelne mellem store og sm&aring; bogstaver',
searchreplace_findnext : 'S&oslash;g efter&nbsp;n&aelig;ste',
searchreplace_replace : 'Erstat',
searchreplace_replaceall : 'Erstat&nbsp;alle',
searchreplace_cancel : 'Fortryd'
});
