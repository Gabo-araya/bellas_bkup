// DK lang variables - Transl.:Jan Moelgaard - Corr.:

tinyMCE.addToLang('',{
save_desc : 'Gem'
});
