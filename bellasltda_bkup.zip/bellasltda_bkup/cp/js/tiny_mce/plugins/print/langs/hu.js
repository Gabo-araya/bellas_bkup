// HU lang variables

tinyMCE.addToLang('',{
print_desc : 'Nyomtatás'
});
