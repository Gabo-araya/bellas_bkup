// HU lang variables

tinyMCE.addToLang('',{
directionality_ltr_desc : 'Elhelyezkedés balról jobbra',
directionality_rtl_desc : 'Elhelyezkedés jobbról balra'
});
