// UK lang variables

/* Remember to namespace the language parameters lang_<your plugin>_<some name> */

tinyMCE.addToLang('',{
template_title : 'This is just a template popup',
template_desc : 'This is just a template button'
});
