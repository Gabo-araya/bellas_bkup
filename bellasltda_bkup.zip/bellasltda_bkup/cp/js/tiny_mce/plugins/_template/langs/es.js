/**
 * ES lang variables
 * 
 * Authors : Alvaro Velasco,
 *           Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>,
 *           Carlos C Soto (eclipxe) <csoto@sia-solutions.com>
 *           Eneko Castresana Vara
 * Last Updated : July 14, 2006
 * TinyMCE Version : 2.0.6.1
 */

tinyMCE.addToLang('',{
template_title : 'Esto es s&oacute;lo la plantilla de un popup',
template_desc : 'Esto es s&oacute;lo la plantilla de un bot&oacute;n'
});
