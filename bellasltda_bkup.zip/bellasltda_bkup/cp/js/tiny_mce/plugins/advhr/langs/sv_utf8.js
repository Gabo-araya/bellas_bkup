// SE lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Skapa/Redigera horisontell linje',
insert_advhr_width : 'Bredd',
insert_advhr_size : 'HÃ¶jd',
insert_advhr_noshade : 'Ingen skugga'
});
