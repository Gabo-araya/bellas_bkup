// NL lang variables

tinyMCE.addToLang('',{
insert_advhr_desc : 'Horizontale lijn invoegen/bewerken',
insert_advhr_width : 'Breedte',
insert_advhr_size : 'Hoogte',
insert_advhr_noshade : 'Geen schaduw'
});
