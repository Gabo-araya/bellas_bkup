// HU lang variables

tinyMCE.addToLang('',{
iespell_desc : 'Helyesírásellenõrzés indítása',
iespell_download : "ieSpell nem található. Kattints az OK-ra a letöltési oldalhoz."
});

