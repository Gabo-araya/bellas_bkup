// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('',{
iespell_desc : 'Lancer le v&eacute;rificateur d\'orthographe',
iespell_download : "Le dictionnaire ieSpell n\'a pas &eacute;t&eacute; trouv&eacute;.\n\nCliquez sur Ok pour aller au site de t&eacute;l&eacute;chargement."
});
