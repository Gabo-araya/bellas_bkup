// HU lang variables

tinyMCE.addToLang('',{
preview_desc : 'Elõnézet'
});
