// SV lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'FullskÃ¤rmslÃ¤ge',
fullscreen_desc : 'Hoppa frÃ¥n/till fullskÃ¤rmslÃ¤ge'
});
