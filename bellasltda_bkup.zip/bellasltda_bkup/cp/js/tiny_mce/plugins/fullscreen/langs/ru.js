// RU lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Полноэкранный режим',
fullscreen_desc : 'Включить полноэкранный режим'
});
