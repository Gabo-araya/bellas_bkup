// HU lang variables

tinyMCE.addToLang('',{
fullscreen_title : 'Teljesképernyõs mód',
fullscreen_desc : 'Váltás teljesképernyõs módra'
});
