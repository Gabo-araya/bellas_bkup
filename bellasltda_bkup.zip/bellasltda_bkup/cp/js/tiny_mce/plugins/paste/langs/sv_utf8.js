// SV lang variables

tinyMCE.addToLang('',{
paste_text_desc : 'Klistra in som vanlig text',
paste_text_title : 'AnvÃ¤nd CTRL+V pÃ¥ ditt tangentbord fÃ¶r att klistra in i detta fÃ¶nster.',
paste_text_linebreaks : 'Spara radbrytningar',
paste_word_desc : 'Klistra in frÃ¥n Word',
paste_word_title : 'AnvÃ¤nd CTRL+V pÃ¥ ditt tangentbord fÃ¶r att klistra in i detta fÃ¶nster.',
selectall_desc : 'Markera allt'
});
