// ES lang variables by Alvaro Velasco and Adolfo Sanz De Diego (asanzdiego) <asanzdiego@yahoo.es>
// Last Updated : October 2005
// TinyMCE Version : 2.0RC3

tinyMCE.addToLang('',{
paste_text_desc : 'Pegar como texto plano',
paste_text_title : 'Use CTRL+V para pegar el texto en la ventana.',
paste_text_linebreaks : 'Mantener saltos de linea',
paste_word_desc : 'Pegar desde Word',
paste_word_title : 'Use CTRL+V para pegar el texto en la ventana.',
selectall_desc : 'Seleccionar todo'
});
