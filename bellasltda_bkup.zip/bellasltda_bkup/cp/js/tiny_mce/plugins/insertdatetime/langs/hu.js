// HU lang variables

tinyMCE.addToLang('',{
insertdate_def_fmt : '%Y-%m-%d',
inserttime_def_fmt : '%H:%M:%S',
insertdate_desc : 'Dátum beszúrása',
inserttime_desc : 'Idõ beszúrása',
inserttime_months_long : new Array("Január", "Február", "Március", "Április", "Május", "Június", "Július", "Augusztus", "Szeptember", "Október", "November", "December"),
inserttime_months_short : new Array("Jan", "Feb", "Már", "Ápr", "Máj", "Jún", "Júl", "Aug", "Sze", "Okt", "Nov", "Dec"),
inserttime_day_long : new Array("Vasárnap", "Hétfõ", "Kedd", "Szerda", "Csütörtök", "Péntek", "Szombat", "Vasárnap"),
inserttime_day_short : new Array("Vas", "Hé", "Ke", "Sze", "Csü", "Pén", "Szo", "Vas")
});
