// FR lang variables
// Modified by Motte, last updated 2006-03-23

tinyMCE.addToLang('',{
insertdate_def_fmt : '%d/%m/%Y',
inserttime_def_fmt : '%Hh%M',
insertdate_desc : 'Ins&eacute;rer la date',
inserttime_desc : 'Ins&eacute;rer l\'heure',
inserttime_months_long : new Array("Janvier", "F&eacute;vrier", "Mars", "Avril", "Mai", "Juin", "Juillet", "Ao&ucirc;t", "Septembre", "Octobre", "Novembre", "D&eacute;cembre"),
inserttime_months_short : new Array("Jan", "F&eacute;v", "Mar", "Avr", "Mai", "Jun", "Jul", "Ao&ucirc;", "Sep", "Oct", "Nov", "D&eacute;c"),
inserttime_day_long : new Array("Dimanche", "Lundi", "Mardi", "Mercredi", "Jeudi", "Vendredi", "Samedi", "Dimanche"),
inserttime_day_short : new Array("Dim", "Lun", "Mar", "Mer", "Jeu", "Ven", "Sam", "Dim")
});
