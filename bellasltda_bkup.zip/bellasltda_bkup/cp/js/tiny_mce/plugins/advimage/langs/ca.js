// UK lang variables

tinyMCE.addToLang('advimage',{
tab_general : 'General',
tab_appearance : 'Aparen&ccedil;a',
tab_advanced : 'Avan&ccedil;cat',
general : 'General',
title : 'T&iacute;tol',
preview : 'Previsulitzaci&oacute;',
constrain_proportions : 'Conserva la proporci&oacute;',
langdir : 'Direcci&oacute; de la llengua',
langcode : 'Codi de la llengua',
long_desc : 'Enlla&ccedil; a la descripci&oacute; llarga',
style : 'Estil',
classes : 'Classe',
ltr : 'Esquerra dreta',
rtl : 'Dreta esquerra',
id : 'Id',
image_map : 'Mapa de la imatge',
swap_image : 'Canvia imatge',
alt_image : 'Imatge alternativa',
mouseover : 'quan el ratol&iacute; arriba',
mouseout : 'quan el ratol&iacute; marxa',
misc : 'Altres',
example_img : 'Aparen&ccedil;a&nbsp;imatge&nbsp;previsualitzada',
missing_alt : 'Esteu segurs que voleu continuar sense incloure una Descripci&oacute de la imatge? Sense descripci&oacute no ser&agrave; accessible per usuaris amb discapacitats, que utilitzen navegadors de text o naveguint amb les imatges deshabilitades.'
});
