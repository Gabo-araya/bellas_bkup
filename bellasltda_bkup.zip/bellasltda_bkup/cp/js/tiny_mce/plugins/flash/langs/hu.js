// HU lang variables

tinyMCE.addToLang('flash',{
title : 'Flash animáció beszúrása / szerkesztése',
desc : 'Flash animáció beszúrása / szerkesztése',
file : 'Flash-Fájl (.swf)',
size : 'Méret',
list : 'Flash fájlok',
props : 'Flash tulajdonságok',
general : 'Általános'
});
