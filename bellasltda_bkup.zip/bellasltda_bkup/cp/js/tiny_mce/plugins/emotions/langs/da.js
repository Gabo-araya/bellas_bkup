// DK lang variables - Transl.:Jan Moelgaard, Bo Frederiksen, John Dalsgaard, Ronny Buelund - Corr.:

tinyMCE.addToLang('emotions',{
title : 'Inds&aelig;t smiley',
desc : 'Smileys',
cool : 'Sej',
cry : 'Gr&aring;der',
embarassed : 'Forlegen',
foot_in_mouth : 'Foden i munden',
frown : 'Rynket pande',
innocent : 'Uskyldig',
kiss : 'Kys',
laughing : 'Latter',
money_mouth : 'L&aelig;kker mund',
sealed : 'Lukket',
smile : 'Smil',
surprised : 'Overrasket',
tongue_out : 'R&aelig;kker tunge',
undecided : 'Usikker',
wink : 'Blinker',
yell : 'R&aring;b'
});
