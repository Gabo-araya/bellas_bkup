<?php header('Location: ../404.php'); ?>   
<?php
       /*
include('inc/inc.inc.php');
$self = str_replace(".","",strrev(strrchr(strrev(basename($_SERVER['PHP_SELF'])),".")));
$title = "Error - P�gina no encontrada";
$secc = "info_".$self;

disp_header_admin($pre,$title);
include('menu.inc.php');

$secc_princ = mysql_query("SELECT ".$secc." FROM ".$pre."info") or die(mysql_error());
  $txt = str_output(mysql_result($secc_princ,0,$secc));

disp_inicio_info($title);

  echo "<h1>$title</h1>";
  echo $txt;

?>
   <ul>
     <li><a href="http://<?php echo $_SERVER['HTTP_HOST']?>/">Haga clic aqu� para ir al inicio del Sitio Web.</a></li>
   </ul>
<?php
  disp_fin_info();
  disp_footer_admin($pre);          */
?>